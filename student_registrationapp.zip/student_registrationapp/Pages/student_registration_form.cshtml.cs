using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace student_registrationapp.Pages
{
    public class student_registration_formModel : PageModel
    {
        static List<Student> students = new List<Student> {
                new Student { StudentId = 1, Name = "sai", Qualification = "B.Tech", Skill = "C#" },
                new Student { StudentId = 2, Name = "Teja", Qualification = "M.Tech", Skill = "Java" },
                new Student { StudentId = 3, Name = "Itachi", Qualification = "MCA", Skill = "Python" }
            };
        [BindProperty]
        public Student Student { get; set; }
        public List<Student> List
        {

            get { return students; }
        }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            students.Add(Student);
            return RedirectToPage("details");
        }
    }

    }

